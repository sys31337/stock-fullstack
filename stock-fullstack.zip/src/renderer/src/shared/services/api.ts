/* eslint-disable camelcase */
import { config as cfg } from '@web/config';
import i18n from 'i18next';
import axios from 'axios';
import authService from '@web/shared/services/auth';
import parseJwt from '@web/shared/utils/parseJWT';
import Any from '@web/shared/types/any';
const noTokenUrls = ['challenge-progress', 'users/login', 'embeds/fetch', 'challenges/fetch'];

const addLocalizationHeaders = (request: Any) => {
  request.headers?.set('Accept-Language', i18n.language);
};

const addAuthHeaders = (request: Any) => {
  request.headers?.delete('x-public');
};

const axiosInstance = axios.create({
  baseURL: `${cfg.baseAppUrl}/api/v1/`,
});

const refreshAccessToken = async (refreshToken: string) => {
  const response = await axios.request({
    method: 'POST',
    url: `${cfg.baseAppUrl}/api/v1/users/token`,
    data: {
      refreshToken,
    },
  });

  const {
    data: { accessToken: token, refreshToken: newRefreshToken, googleToken },
  } = response;
  const { userId, fullname } = parseJwt(token);

  const userData = {
    userId,
    fullname,
    token,
    refreshToken: newRefreshToken,
    googleToken,
  };

  authService.saveUserInfo(userData);
  return response;
};

axiosInstance.interceptors.request.use(
  async (config) => {
    if (noTokenUrls.some((substring) => (config.url as string).includes(substring))) return config;
    const { refreshToken, token: accessToken }: Any = authService.loadUserInfo() || { googleAccessToken: null, googleTokenExpiresAt: Date.now() - 3600 };
    if (refreshToken && accessToken) {
      const expiresAt = parseJwt(accessToken).exp;
      const currentTime = Math.ceil(Date.now() / 1000);
      const notExpired = currentTime < expiresAt;
      if (notExpired) {
        config.headers.Authorization = `Bearer ${accessToken}`;
      } else {
        try {
          const response = await refreshAccessToken(refreshToken);
          const { data } = response;
          const { accessToken: at } = data;
          config.headers.Authorization = `Bearer ${at}`;
        } catch (error) {
          authService.resetUserInfo();
          window.location.hash = '#/connexion';
        }
      }
    }
    addAuthHeaders(config);
    addLocalizationHeaders(config);
    return config;
  },
);

axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const isUnauthorized = error.response?.status === 401 || error.response?.status === 403;
    if (isUnauthorized) {
      authService.resetUserInfo();
      window.location.hash = '#/connexion';
    }
    return Promise.reject(error);
  },
);

export default axiosInstance;
